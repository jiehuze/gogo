# _PWD = ['Dearcc2018@02',
#         'Dearccbj2018@02',
#         'Bjmrs@2020',
#         'C1oudTest',
#         'En0v@te2019bj',
#         'En0v@te2020bj',
#         'i8zKgKcrX2o17qo2',
#         'gJfMJpw=2020bj',
#         'EnF8V@Bp5rIhzQ==84i',
#         'MIGfMA0GCSqGSIb3',
#         'Bigdata@gfCu%-2020bj',
#         'KcBiwBeQ==@teG2020bj']

_PWD = {0: 'Dearcc2018@02',
        1: 'Dearccbj2018@02',
        2: 'Bjmrs@2020',
        3: 'C1oudTest',
        4: 'En0v@te2019bj',
        5: 'En0v@te2020bj',
        6: 'i8zKgKcrX2o17qo2',
        7: 'gJfMJpw=2020bj',
        8: 'EnF8V@Bp5rIhzQ==84i',
        9: 'MIGfMA0GCSqGSIb3',
        10: 'Bigdata@gfCu%-2020bj',
        11: 'KcBiwBeQ==@teG2020bj',
        12: 'Long@123qwe',
        13: 'dearcc2018@0',
        14: 'xiaohu#840812',
        15: 'Dearcc2022@01'}
_HOST = [
    {'host': '192.168.0.222', 'pwd': 14, 'desc': 'jumpserver', 'user': 'yushuilong','port':'2222'},
    {'host': '192.168.0.180', 'pwd': 15, 'desc': 'pki', 'user': 'root','port':'22'},

    {'host': '192.168.100.7', 'pwd': 3, 'desc': 'dev', 'user': 'cloud'},

    {'host': '192.168.0.90', 'pwd': 7, 'desc': 'test', 'user': 'root'},
    {'host': '192.168.0.25', 'pwd': 7, 'desc': 'test', 'user': 'root'},
    {'host': '192.168.0.209', 'pwd': 7, 'desc': 'test', 'user': 'root'},
    {'host': '192.168.0.107', 'pwd': 7, 'desc': 'test', 'user': 'root'},

    {'host': '114.115.219.13', 'pwd': 0, 'desc': 'test-25', 'user': 'root'},
    {'host': '114.115.167.116', 'pwd': 7, 'desc': 'test-209', 'user': 'root'},

    {'host': '192.168.0.61', 'pwd': 11, 'desc': 'online', 'user': 'root'},
    {'host': '192.168.0.55', 'pwd': 11, 'desc': 'online', 'user': 'root'},
    {'host': '192.168.0.12', 'pwd': 11, 'desc': 'online', 'user': 'root'},

    {'host': '114.115.144.166', 'pwd': 11, 'desc': 'online***', 'user': 'root'},

    {'host': '192.168.0.150', 'pwd': 8, 'desc': 'zk/k8s', 'user': 'root'},
    {'host': '192.168.0.219', 'pwd': 8, 'desc': 'zk/k8s', 'user': 'root'},
    {'host': '192.168.0.221', 'pwd': 8, 'desc': 'zk/k8s', 'user': 'root'},

    {'host': '192.168.0.240', 'pwd': 10, 'desc': 'Bigdata-test', 'user': 'root'},
    {'host': '192.168.0.23', 'pwd': 10, 'desc': 'Bigdata-test(dataupload)', 'user': 'root'},
    {'host': '192.168.0.224', 'pwd': 10, 'desc': 'Bigdata-online', 'user': 'root'},
    {'host': '192.168.0.27', 'pwd': 10, 'desc': 'Bigdata-online', 'user': 'root'},

    {'host': '192.168.3.221', 'pwd': 8, 'desc': 'MRS-online(node-master1JWfv)', 'user': 'root'},
    {'host': '192.168.3.169', 'pwd': 8, 'desc': 'MRS-online(node_master2mDdX)', 'user': 'root'},
    {'host': '192.168.3.165', 'pwd': 2, 'desc': 'MRS-online(node-str-coretrrl0001)', 'user': 'root'},
    {'host': '192.168.3.181', 'pwd': 2, 'desc': 'MRS-online(node-str-coretrrl0002)', 'user': 'root'},
    {'host': '192.168.3.203', 'pwd': 2, 'desc': 'MRS-online(node-str-coretrrl0003)', 'user': 'root'},
    {'host': '192.168.3.135', 'pwd': 2, 'desc': 'MRS-online(node-ana-coreQbvV0001)', 'user': 'root'},
    {'host': '192.168.3.83', 'pwd': 2, 'desc': 'MRS-online(node-ana-coreQbvV0002)', 'user': 'root'},
    {'host': '192.168.3.50', 'pwd': 2, 'desc': 'MRS-online(node-ana-coreQbvV0003)', 'user': 'root'},
    {'host': '192.168.3.32', 'pwd': 2, 'desc': 'MRS-online(node-ana-coreazu8e)', 'user': 'root'},

    {'host': '192.168.0.215', 'pwd': 2, 'desc': 'MRS-test(node-master1GLfG)', 'user': 'root'},
    {'host': '192.168.0.77', 'pwd': 2, 'desc': 'MRS-test(node-master2IlcH)', 'user': 'root'},
    {'host': '192.168.0.11', 'pwd': 2, 'desc': 'MRS-test(node-str-coreBTmh)', 'user': 'root'},
    {'host': '192.168.0.173', 'pwd': 2, 'desc': 'MRS-test(node-ana-coretLaB)', 'user': 'root'},
    {'host': '192.168.0.40', 'pwd': 2, 'desc': 'MRS-test(node-ana-coretkxi)', 'user': 'root'},
    {'host': '192.168.0.43', 'pwd': 2, 'desc': 'MRS-test(node-ana-corexhHj)', 'user': 'root'},

    {'host': '192.168.0.66', 'pwd': 8, 'desc': 'EMQ-online', 'user': 'root'},
    {'host': '192.168.0.86', 'pwd': 8, 'desc': 'EMQ-online', 'user': 'root'},

    {'host': '192.168.0.135', 'pwd': 6, 'desc': 'iot/jinshan', 'user': 'root'},
    {'host': '192.168.0.105', 'pwd': 6, 'desc': 'iot/jinshan', 'user': 'root'},
    {'host': '192.168.0.41', 'pwd': 6, 'desc': 'iot/jinshan', 'user': 'root'},
    {'host': '192.168.0.4', 'pwd': 8, 'desc': 'AIJL-114.116.183.248', 'user': 'root'},

    {'host': '192.168.0.67', 'pwd': 10, 'desc': 'nginx/web/code-114.115.208.31', 'user': 'root'},
    {'host': '192.168.0.230', 'pwd': 10, 'desc': 'nginx/web/code-114.115.144.160', 'user': 'root'},

    {'host': '192.168.0.237', 'pwd': 12, 'desc': 'kafka-detail', 'user': 'ysl'},

    {'host': '192.168.0.230', 'pwd': 11, 'desc': 'kafka-detail', 'user': 'root'},
    {'host': '192.168.0.153', 'pwd': 11, 'desc': 'kafka-detail', 'user': 'root'},
    {'host': '122.112.205.89', 'pwd': 13, 'desc': 'dk01', 'user': 'root','port':'2222'},
]
